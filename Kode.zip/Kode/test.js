let chai = require("chai");
let chaiHttp = require("chai-http");
const { response } = require("express");

let server = require("./server");
let t = require("./routes/users");
const { expect } = require("chai");

//Assertion
chai.should();
chai.use(chaiHttp);
describe('GET users', () => {
    //test get
    describe("Check CRUD", () => {
        it("it should check endpoints", (done) => {
            chai.request(t)
            .get("http://localhost:3000/users")
            .end((err, response) => {
                response.should.have.a.status(200);
                response.should.have.property('age')
                //der kunne tilføjes yderligere 
                done();
            })
        })
    })
})
