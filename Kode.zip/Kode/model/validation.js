const Joi = require('joi');

//skrevet til pseudo, så ikke med intention at skulle virke
function inputValidation(){
    const schema = Joi.object({
        fName : Joi.string().required(),
        lName : Joi.string().required(),
        gender : Joi.string().required(),
        age : Joi.number().required(),
        mail : Joi.string().required(),
        pWord : Joi.string().min(6).required()
    })
}

