
var mail = document.getElementById("mail");
var pword = document.getElementById("pword");



function validate() {
    var errorID = document.getElementById("fail");
    errorID.innerHTML = " "


    var x = mail.value;
    if (x == "") {
        errorID.innerHTML += "Fill out Email name <br>";
    }

    var x = pword.value;
    if (x == "") {
        errorID.innerHTML += "Fill out Password name <br><br>";
    }

    if (mail.value && pword.value !==""){
        window.location.href = "http://127.0.0.1:5501/view/inside.html"
    }


}



function link() {
    var errorID = document.getElementById("link");
    errorID.innerHTML = " "

    window.location.href = "http://127.0.0.1:5501/view/signup.html"
}

