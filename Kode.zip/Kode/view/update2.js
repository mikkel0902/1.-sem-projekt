const axios = require('axios');

var fName = document.getElementById("fname");
var lName = document.getElementById("lname");
var age = document.getElementById("age");
var gender = document.getElementById("gender");

function updateUser() {
    axios.put('localhost:5501/users/', {​​​​​​​​
        firstName: fName,
        lastName: lName,
        age: age,
        gender: gender
      }​​​​​​​​)
      .then(function (response) {​​​​​​​​
        console.log(response);
      }​​​​​​​​)
      .catch(function (error) {​​​​​​​​
        console.log(error);
      }​​​​​​​​);
}

function deleteUser() {
    axios.delete('localhost:5501/users/', {​​​​​​​​

      }​​​​​​​​)
      .then(function (response) {​​​​​​​​
        console.log(response);
      }​​​​​​​​)
      .catch(function (error) {​​​​​​​​
        console.log(error);
      }​​​​​​​​);
}




function loginPage() {
  window.location.href = "http://127.0.0.1:5501/view/login.html"
}

function homepageLink() {
  window.location.href = "http://127.0.0.1:5501/view/inside.html"
}