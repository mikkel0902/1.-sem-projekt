const axios = require('axios');

var fName = document.getElementById("fname");
var lName = document.getElementById("lname");
var age = document.getElementById("age");
var gender = document.getElementById("gender");
var mail = document.getElementById("mail");
var pWord = document.getElementById("pword");
var pWordMes = document.getElementById("pwordmes");


function validate() {
var x = fName.value;
var errorID = document.getElementById("fail");
errorID.innerHTML = " "
if (x == "") {
    errorID.innerHTML += "Fill out First name <br>";
}

var x = lName.value;
if (x == "") {
    errorID.innerHTML += "Fill out Last name <br>";
}

var x = age.value;
if (x == "") {
    errorID.innerHTML += "Fill out Age <br>";
}

var x = gender.value;
if (x == "") {
    errorID.innerHTML += "Fill out Gender <br>";
}

var x = mail.value;
if (x == "") {
    errorID.innerHTML += "Fill out Email name <br>";
}

var x = pWord.value;
if (x == "") {
    errorID.innerHTML += "Fill out Password name <br><br>";
} 
else{window.location.href = "http://127.0.0.1:5501/view/login.html";}
}

pWord.addEventListener("keydown"&&"keyup", pWordValidation);

function pWordValidation() {
    let xs = document.getElementById("pword").value.length;
    
    try {
    if (xs < 8) {
        throw "Too short password";
    } 
    else {
        document.getElementById("pWordMes").innerHTML = "";
    }
} catch(fejl) {
    document.getElementById("pWordMes").innerHTML = fejl;
    }
}


function onSubmit(){
    axios.post('localhost:5501/users', {​​​​​​​​
        firstName: fName,
        lastName: lName,
        age: age,
        gender: gender,
        mail: mail,
        password: pWord,

      }​​​​​​​​)
      .then(function (response) {​​​​​​​​
        console.log(response);
      }​​​​​​​​)
      .catch(function (error) {​​​​​​​​
        console.log(error);
      }​​​​​​​​);
}

    

function link() {
    var errorID = document.getElementById("link");
    errorID.innerHTML = " "

    window.location.href = "http://127.0.0.1:5501/view/login.html"
}