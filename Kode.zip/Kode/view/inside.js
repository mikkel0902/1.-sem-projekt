
function logOut() {
    window.location.href = "http://127.0.0.1:5501/view/login.html"

    //delete JWT token
}

function updateUser() {
    window.location.href = "http://127.0.0.1:5501/view/update.html"
}