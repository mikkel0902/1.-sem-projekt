
const userRoutes = (app, fs) => {

    const dataPath = './db/users.json';

    //definerer readfile
    const readFile = (callback, returnJson = false, filePath = dataPath, encoding = "utf8") => {
        fs.readFile(filePath, encoding, (err, data) => {
            if (err) {
                throw err;
            }
            //callback er vigtigt. Fortæller når readFile() er færdig.
            callback(returnJson ? JSON.parse(data) : data); 
        }); 
    };
    //definerer writefile
    const writeFile = (fileData, callback, filePath = dataPath, encoding = "utf8") => {
        fs.writeFile(filePath, fileData, encoding, (err) => {
            if (err) {
                throw err;
            }
            callback();
        });
    };

    // all users
    app.get("/users", (req, res) => {
        fs.readFile(dataPath, "utf8", (err, data) => {
            if (err) {
                throw err;
            }
            res.send(JSON.parse(data));
        });
    });

    // create user. Skal først hente den nuværende data, som jeg bruger til at definere min nye user
    app.post("/users", (req, res) => {
        readFile(data => {
            const newUserId = Object.keys(data).length + 1;
            data[newUserId.toString()] = req.body;
            //stringify oversætter js-objekt til JSON.
            writeFile(JSON.stringify(data, null, 2), () => {
                res.status(200).send("user signed up");
            });
        }, true);
    });


    //update user
    app.put("/users/:id", (req, res) => {
        readFile(data => {
            const userId = req.params["id"];
            data[userId] = req.body;
            writeFile(JSON.stringify(data, null, 2), () => {
                res.status(200).send(`users id:${userId} updated`);
            });
        }, true);
    });


    //delete user
    app.delete("/users/:id", (req, res) => {
        readFile(data => {
            const userId = req.params["id"];
            delete data[userId];
            writeFile(JSON.stringify(data, null, 2), () => {
                res.status(200).send(`users id:${userId} removed`);
            });
        }, true);
    });
};

module.exports = userRoutes;

