/*
const express = require("express");
const router = express.Router();

const users = require("../db/users.json");


  //Denne del mangler, hvori ID'et fra de to users som har matchet, findes og gemmes
  //Den information kan jeg senere bruge til at display for de enkelte brugere
  //Dvs. når man vil se hvilke matches man har fået

  //Pseudo
  henter de andre brugere fra databasen, men kun med de relevante paramtre.
  get.user: (id, fName, lName, age, gender)
  likeFunktion(){
    user.id, som kan likes
    hvis like,
    id sendes til matches.json
  }

  matchFunktion(){
    forloop tjekker for hvem har liked og kommer dem i likeArray
    hvis user1 har user2 i likeArray, og user2 har user1 i likeArray
    match found 
  }
  

  res.send(JSON.stringify(matched));
});

module.exports = router;
*/
