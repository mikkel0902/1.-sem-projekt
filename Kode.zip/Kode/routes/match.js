/*
const express = require("express");
const router = express.Router();

const users = require("../db/users.json");

router.get("/:age", (req, res) => {
  
  let users = [freeUsers, paymentUsers];
  let matched = ["Match found "];

  (Denne del mangler, hvori ID'et fra de to users som har matchet, findes og gemmes)
  (Den information kan jeg senere bruge til at display for de enkelte brugere)
  (Dvs. når man vil se hvilke matches man har fået)

  res.send(JSON.stringify(matched));
});

module.exports = router;

*/


